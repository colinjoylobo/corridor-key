#!/usr/bin/env bash
set -euo pipefail

# ============================================================================
# CorridorKey — Full Setup Script for Azure (or any Linux VM with GPU)
#
# What this does:
#   1. Installs system deps (git, ffmpeg, etc.)
#   2. Installs uv (Python package manager)
#   3. Clones the CorridorKey repo
#   4. Installs Python dependencies
#   5. Downloads model weights
#   6. Copies in the FastAPI server (api.py)
#   7. Creates a systemd service so the API starts on boot
#
# Usage:
#   chmod +x setup.sh
#   sudo ./setup.sh
#
# After setup:
#   - API runs on port 8000 (http://YOUR_VM_IP:8000)
#   - Docs at http://YOUR_VM_IP:8000/docs
#   - Manage: sudo systemctl {start|stop|restart|status} corridorkey
#   - Logs:   sudo journalctl -u corridorkey -f
# ============================================================================

APP_DIR="/opt/corridorkey"
REPO_URL="https://github.com/nikopueringer/CorridorKey.git"
API_PORT="${API_PORT:-8000}"
API_HOST="${API_HOST:-0.0.0.0}"

echo "============================================"
echo " CorridorKey — Azure Setup"
echo "============================================"

# ------------------------------------------------------------------
# 1. System dependencies
# ------------------------------------------------------------------
echo "[1/7] Installing system dependencies..."
apt-get update -qq
apt-get install -y -qq git curl ffmpeg libgl1-mesa-glx libglib2.0-0 > /dev/null

# ------------------------------------------------------------------
# 2. Install uv
# ------------------------------------------------------------------
echo "[2/7] Installing uv..."
if ! command -v uv &> /dev/null; then
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
fi
echo "  uv version: $(uv --version)"

# ------------------------------------------------------------------
# 3. Clone repo
# ------------------------------------------------------------------
echo "[3/7] Cloning CorridorKey..."
if [ -d "$APP_DIR" ]; then
    echo "  $APP_DIR already exists, pulling latest..."
    cd "$APP_DIR" && git pull --ff-only || true
else
    git clone "$REPO_URL" "$APP_DIR"
fi
cd "$APP_DIR"

# ------------------------------------------------------------------
# 4. Install Python dependencies
# ------------------------------------------------------------------
echo "[4/7] Installing Python dependencies..."
uv sync --no-dev
uv pip install boto3

# ------------------------------------------------------------------
# 5. Download model weights
# ------------------------------------------------------------------
echo "[5/7] Downloading CorridorKey model weights..."
CKPT_DIR="$APP_DIR/CorridorKeyModule/checkpoints"
mkdir -p "$CKPT_DIR"
if [ ! -f "$CKPT_DIR/CorridorKey.pth" ]; then
    uv run python -c "
from huggingface_hub import hf_hub_download
hf_hub_download('nikopueringer/CorridorKey_v1.0', 'CorridorKey_v1.0.pth',
                local_dir='$CKPT_DIR')
"
    mv "$CKPT_DIR/CorridorKey_v1.0.pth" "$CKPT_DIR/CorridorKey.pth"
    echo "  Downloaded CorridorKey.pth ($(du -h "$CKPT_DIR/CorridorKey.pth" | cut -f1))"
else
    echo "  CorridorKey.pth already present"
fi

# ------------------------------------------------------------------
# 6. Copy FastAPI server
# ------------------------------------------------------------------
echo "[6/7] Installing FastAPI server..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -f "$SCRIPT_DIR/api.py" ]; then
    cp "$SCRIPT_DIR/api.py" "$APP_DIR/api.py"
    echo "  Copied api.py from deploy package"
else
    echo "  api.py already in repo or missing from package — skipping copy"
fi

# ------------------------------------------------------------------
# 7. Create systemd service
# ------------------------------------------------------------------
echo "[7/7] Creating systemd service..."

UV_PATH="$(which uv)"

cat > /etc/systemd/system/corridorkey.service << UNIT
[Unit]
Description=CorridorKey FastAPI Server
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
ExecStart=$UV_PATH run python api.py --host $API_HOST --port $API_PORT
Restart=on-failure
RestartSec=10
Environment=PATH=$HOME/.local/bin:/usr/local/bin:/usr/bin:/bin
Environment=CORRIDORKEY_DEVICE=auto

# Set these for S3 output uploads (optional):
# Environment=BUCKET_ENDPOINT_URL=https://your-s3-endpoint.com
# Environment=BUCKET_ACCESS_KEY_ID=your-key
# Environment=BUCKET_SECRET_ACCESS_KEY=your-secret
# Environment=BUCKET_NAME=your-bucket

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable corridorkey
systemctl start corridorkey

echo ""
echo "============================================"
echo " Setup complete!"
echo "============================================"
echo ""
echo " API running at: http://$API_HOST:$API_PORT"
echo " Docs at:        http://$API_HOST:$API_PORT/docs"
echo ""
echo " Manage the service:"
echo "   sudo systemctl status corridorkey"
echo "   sudo systemctl restart corridorkey"
echo "   sudo journalctl -u corridorkey -f"
echo ""
echo " Open port $API_PORT in your Azure NSG/firewall"
echo " to access the API from outside the VM."
echo ""
