#!/usr/bin/env python3
"""CorridorKey — FastAPI REST API for green screen keying, background replacement & roto.

Usage:
    uv run python api.py                    # Start on 0.0.0.0:8000
    uv run python api.py --port 9000        # Custom port
    uv run uvicorn api:app --reload         # Dev mode
"""

from __future__ import annotations

import json
import logging
import os
import queue
import shutil
import threading
import uuid
import zipfile
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from enum import Enum
from io import BytesIO
from pathlib import Path
from typing import Any

import cv2
import numpy as np
from fastapi import FastAPI, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel, Field

from device_utils import resolve_device

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
JOBS_DIR = BASE_DIR / "api_jobs"
JOBS_DIR.mkdir(exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("corridorkey.api")


# ---------------------------------------------------------------------------
# Enums & Pydantic models
# ---------------------------------------------------------------------------

class JobType(str, Enum):
    background_replace = "background_replace"
    greenscreen_key = "greenscreen_key"
    rotoscope = "rotoscope"


class JobStatus(str, Enum):
    queued = "queued"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"


class DeviceChoice(str, Enum):
    auto = "auto"
    cuda = "cuda"
    mps = "mps"
    cpu = "cpu"


# --- Request param models (sent as JSON string in form field) ---

class BackgroundReplaceParams(BaseModel):
    bg_color: str = Field("#000000", description="Hex color fallback, e.g. #0080FF")
    device: DeviceChoice = DeviceChoice.auto
    gvm_batch: int = Field(4, ge=1, le=12)
    gvm_ensemble: int = Field(1, ge=1, le=5)
    gvm_overlap: int = Field(2, ge=1, le=4)
    refine_threshold: int = Field(0, ge=0, le=255)
    refine_erode: int = Field(0, ge=0, le=10)
    refine_dilate: int = Field(0, ge=0, le=10)
    refine_blur: int = Field(0, ge=0, le=21)
    refine_min_area: int = Field(0, ge=0)
    refine_temporal_smooth: int = Field(0, ge=0, le=10)
    keep_mattes: bool = False


class GreenScreenKeyParams(BaseModel):
    device: DeviceChoice = DeviceChoice.auto
    use_gvm_alpha: bool = Field(True, description="Auto-generate alpha hint with GVM if no alpha_hint uploaded")
    input_is_linear: bool = False
    despill_strength: float = Field(0.5, ge=0.0, le=1.0)
    auto_despeckle: bool = True
    despeckle_size: int = Field(400, ge=0)
    refiner_scale: float = Field(1.0, ge=0.0, le=3.0)
    max_frames: int = Field(0, ge=0, description="0 = process all frames")


class RotoscopeParams(BaseModel):
    device: DeviceChoice = DeviceChoice.auto
    gvm_batch: int = Field(4, ge=1, le=12)
    gvm_ensemble: int = Field(1, ge=1, le=5)
    gvm_overlap: int = Field(2, ge=1, le=4)
    refine_threshold: int = Field(0, ge=0, le=255)
    refine_erode: int = Field(0, ge=0, le=10)
    refine_dilate: int = Field(0, ge=0, le=10)
    refine_blur: int = Field(0, ge=0, le=21)
    refine_min_area: int = Field(0, ge=0)
    refine_temporal_smooth: int = Field(0, ge=0, le=10)
    export_transparent_pngs: bool = True
    export_subject_video: bool = True
    export_matte_video: bool = True
    subject_bg_color: str = Field("#000000", description="Hex background for subject video")


# --- Response models ---

class ResultFile(BaseModel):
    name: str
    path: str = Field(description="Relative path under job output dir")
    content_type: str = "application/octet-stream"
    size_bytes: int = 0


class JobResponse(BaseModel):
    job_id: str
    job_type: JobType
    status: JobStatus
    created_at: str
    started_at: str | None = None
    completed_at: str | None = None
    progress: str | None = None
    error: str | None = None
    result_files: list[ResultFile] = []


# ---------------------------------------------------------------------------
# Job store (in-memory + disk-backed)
# ---------------------------------------------------------------------------

_jobs: dict[str, dict[str, Any]] = {}
_jobs_lock = threading.Lock()
_job_queue: queue.Queue[str | None] = queue.Queue()  # job_id or None = shutdown


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _job_dir(job_id: str) -> Path:
    return JOBS_DIR / job_id


def _save_meta(job_id: str) -> None:
    """Persist job metadata to disk."""
    with _jobs_lock:
        meta = _jobs.get(job_id)
        if meta is None:
            return
        meta_copy = {k: v for k, v in meta.items()}
    path = _job_dir(job_id) / "job.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(meta_copy, indent=2))


def _update_job(job_id: str, **kwargs: Any) -> None:
    with _jobs_lock:
        if job_id in _jobs:
            _jobs[job_id].update(kwargs)
    _save_meta(job_id)


def _create_job(job_id: str, job_type: JobType, params: dict) -> dict:
    meta = {
        "job_id": job_id,
        "job_type": job_type.value,
        "status": JobStatus.queued.value,
        "created_at": _now(),
        "started_at": None,
        "completed_at": None,
        "progress": None,
        "error": None,
        "params": params,
    }
    with _jobs_lock:
        _jobs[job_id] = meta
    _save_meta(job_id)
    return meta


def _get_job(job_id: str) -> dict | None:
    with _jobs_lock:
        return _jobs.get(job_id)


def _load_jobs_on_startup() -> None:
    """Recover completed/failed jobs from disk on startup."""
    if not JOBS_DIR.exists():
        return
    for d in JOBS_DIR.iterdir():
        if not d.is_dir():
            continue
        meta_path = d / "job.json"
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text())
                # Don't re-queue running jobs — mark them as failed
                if meta.get("status") == JobStatus.running.value:
                    meta["status"] = JobStatus.failed.value
                    meta["error"] = "Server restarted while job was running"
                with _jobs_lock:
                    _jobs[meta["job_id"]] = meta
            except Exception:
                logger.warning(f"Failed to load job metadata from {meta_path}")


def _scan_result_files(job_id: str) -> list[ResultFile]:
    """Scan the output directory and return a manifest of result files."""
    output_dir = _job_dir(job_id) / "output"
    if not output_dir.exists():
        return []
    results = []
    for p in sorted(output_dir.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(output_dir)
        ct = _guess_content_type(p.suffix)
        results.append(ResultFile(
            name=p.name,
            path=str(rel),
            content_type=ct,
            size_bytes=p.stat().st_size,
        ))
    return results


def _guess_content_type(ext: str) -> str:
    return {
        ".mp4": "video/mp4",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".exr": "image/x-exr",
        ".zip": "application/zip",
    }.get(ext.lower(), "application/octet-stream")


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------

async def _save_upload(upload: UploadFile, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with open(dest, "wb") as f:
        while chunk := await upload.read(1024 * 1024):
            f.write(chunk)


def _make_zip(directory: Path) -> BytesIO:
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(directory.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(directory))
    buf.seek(0)
    return buf


# ---------------------------------------------------------------------------
# Worker — processes jobs sequentially on the GPU
# ---------------------------------------------------------------------------

def _worker_loop() -> None:
    """Pull jobs from the queue and execute them one at a time."""
    while True:
        job_id = _job_queue.get()
        if job_id is None:
            break  # shutdown signal

        meta = _get_job(job_id)
        if meta is None or meta["status"] == JobStatus.cancelled.value:
            continue

        _update_job(job_id, status=JobStatus.running.value, started_at=_now())

        try:
            jt = meta["job_type"]
            if jt == JobType.background_replace.value:
                _run_bg_replace(job_id)
            elif jt == JobType.greenscreen_key.value:
                _run_greenscreen(job_id)
            elif jt == JobType.rotoscope.value:
                _run_rotoscope(job_id)
            else:
                raise ValueError(f"Unknown job type: {jt}")
            _update_job(job_id, status=JobStatus.completed.value, completed_at=_now())
        except Exception as exc:
            logger.exception(f"Job {job_id} failed")
            _update_job(job_id, status=JobStatus.failed.value, error=str(exc), completed_at=_now())


# --- Job handlers ---

def _run_bg_replace(job_id: str) -> None:
    from replace_background import (
        _unload_gvm,
        composite_video,
        filter_mattes_by_selection,
        generate_mattes,
        load_background,
        refine_mattes,
    )

    jdir = _job_dir(job_id)
    inp = jdir / "input"
    out = jdir / "output"
    out.mkdir(exist_ok=True)

    meta = _get_job(job_id)
    p = BackgroundReplaceParams(**meta["params"])
    device = resolve_device(p.device.value)

    video_path = str(inp / "video.mp4")
    cap = cv2.VideoCapture(video_path)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 24.0
    cap.release()

    # Step 1: Generate mattes
    _update_job(job_id, progress="Step 1/4: Generating mattes with GVM...")
    matte_dir = str(out / "mattes")
    os.makedirs(matte_dir, exist_ok=True)
    generate_mattes(
        video_path, matte_dir, device,
        num_frames_per_batch=p.gvm_batch,
        ensemble_size=p.gvm_ensemble,
        num_overlap_frames=p.gvm_overlap,
    )

    # Step 2: Filter by selection mask (if provided)
    mask_path = inp / "selection_mask.png"
    if mask_path.exists():
        _update_job(job_id, progress="Step 2/4: Filtering by selection...")
        sel_mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
        if sel_mask is not None:
            sel_mask = cv2.resize(sel_mask, (w, h), interpolation=cv2.INTER_NEAREST)
            filter_mattes_by_selection(matte_dir, sel_mask)

    # Step 3: Refine mattes
    needs_refine = any([
        p.refine_threshold, p.refine_erode, p.refine_dilate,
        p.refine_blur, p.refine_min_area, p.refine_temporal_smooth,
    ])
    if needs_refine:
        _update_job(job_id, progress="Step 3/4: Refining mattes...")
        refine_mattes(
            matte_dir,
            threshold=p.refine_threshold,
            erode=p.refine_erode,
            dilate=p.refine_dilate,
            blur=p.refine_blur,
            min_area=p.refine_min_area,
            temporal_smooth=p.refine_temporal_smooth,
        )

    # Step 4: Composite
    _update_job(job_id, progress="Step 4/4: Compositing...")
    bg_video_path = inp / "background_video.mp4"
    bg_image_path = inp / "background_image.png"

    if bg_video_path.exists():
        bg_source = str(bg_video_path)
    elif bg_image_path.exists():
        bg_source = load_background(str(bg_image_path), w, h)
    else:
        bg_source = load_background(p.bg_color, w, h)

    output_path = str(out / "result.mp4")
    composite_video(video_path, matte_dir, bg_source, output_path, fps)

    if not p.keep_mattes:
        shutil.rmtree(matte_dir, ignore_errors=True)

    _unload_gvm()


def _run_greenscreen(job_id: str) -> None:
    from replace_background import _unload_gvm, generate_mattes, run_greenscreen_key

    jdir = _job_dir(job_id)
    inp = jdir / "input"
    out = jdir / "output"
    out.mkdir(exist_ok=True)

    meta = _get_job(job_id)
    p = GreenScreenKeyParams(**meta["params"])
    device = resolve_device(p.device.value)

    video_path = str(inp / "video.mp4")
    alpha_path = inp / "alpha_hint.mp4"

    # Generate alpha hint with GVM if not provided
    if not alpha_path.exists() and p.use_gvm_alpha:
        _update_job(job_id, progress="Generating AlphaHint with GVM...")
        matte_tmp = out / "AlphaHint_generated"
        matte_tmp.mkdir(exist_ok=True)
        generate_mattes(video_path, str(matte_tmp), device)

        # Stitch matte PNGs into a video
        matte_files = sorted(f for f in os.listdir(str(matte_tmp)) if f.endswith(".png"))
        if not matte_files:
            raise RuntimeError("GVM produced no matte frames.")
        first_matte = cv2.imread(str(matte_tmp / matte_files[0]))
        mh, mw = first_matte.shape[:2]
        alpha_vid = str(out / "alpha_hint.mp4")
        cap_tmp = cv2.VideoCapture(video_path)
        fps = cap_tmp.get(cv2.CAP_PROP_FPS) or 24.0
        cap_tmp.release()
        writer = cv2.VideoWriter(alpha_vid, cv2.VideoWriter_fourcc(*"mp4v"), fps, (mw, mh))
        for mf in matte_files:
            writer.write(cv2.imread(str(matte_tmp / mf)))
        writer.release()
        alpha_path = Path(alpha_vid)
        _unload_gvm()
    elif not alpha_path.exists():
        raise RuntimeError("No alpha hint provided and GVM auto-generation is disabled.")

    _update_job(job_id, progress="Running CorridorKey inference...")
    max_f = p.max_frames if p.max_frames > 0 else None
    run_greenscreen_key(
        video_path=video_path,
        alpha_hint_path=str(alpha_path),
        output_dir=str(out),
        device=p.device.value,
        input_is_linear=p.input_is_linear,
        despill_strength=p.despill_strength,
        auto_despeckle=p.auto_despeckle,
        despeckle_size=p.despeckle_size,
        refiner_scale=p.refiner_scale,
        max_frames=max_f,
    )


def _run_rotoscope(job_id: str) -> None:
    from replace_background import (
        _unload_gvm,
        export_matte_video,
        export_subject_video,
        export_transparent_pngs,
        filter_mattes_by_selection,
        generate_mattes,
        parse_color,
        refine_mattes,
    )

    jdir = _job_dir(job_id)
    inp = jdir / "input"
    out = jdir / "output"
    out.mkdir(exist_ok=True)

    meta = _get_job(job_id)
    p = RotoscopeParams(**meta["params"])
    device = resolve_device(p.device.value)

    video_path = str(inp / "video.mp4")

    # Get video info
    cap = cv2.VideoCapture(video_path)
    vw = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    vh = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 24.0
    cap.release()

    # Step 1: Generate mattes
    _update_job(job_id, progress="Generating mattes with GVM...")
    matte_dir = str(out / "mattes")
    os.makedirs(matte_dir, exist_ok=True)
    generate_mattes(
        video_path, matte_dir, device,
        num_frames_per_batch=p.gvm_batch,
        ensemble_size=p.gvm_ensemble,
        num_overlap_frames=p.gvm_overlap,
    )

    # Step 2: Filter by selection mask
    mask_path = inp / "selection_mask.png"
    if mask_path.exists():
        _update_job(job_id, progress="Filtering by selection...")
        sel_mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
        if sel_mask is not None:
            sel_mask = cv2.resize(sel_mask, (vw, vh), interpolation=cv2.INTER_NEAREST)
            filter_mattes_by_selection(matte_dir, sel_mask)

    # Step 3: Refine
    needs_refine = any([
        p.refine_threshold, p.refine_erode, p.refine_dilate,
        p.refine_blur, p.refine_min_area, p.refine_temporal_smooth,
    ])
    if needs_refine:
        _update_job(job_id, progress="Refining mattes...")
        refine_mattes(
            matte_dir,
            threshold=p.refine_threshold,
            erode=p.refine_erode,
            dilate=p.refine_dilate,
            blur=p.refine_blur,
            min_area=p.refine_min_area,
            temporal_smooth=p.refine_temporal_smooth,
        )

    # Step 4: Exports
    if p.export_transparent_pngs:
        _update_job(job_id, progress="Exporting transparent PNGs...")
        png_dir = str(out / "transparent_pngs")
        export_transparent_pngs(video_path, matte_dir, png_dir)

    if p.export_subject_video:
        _update_job(job_id, progress="Exporting subject video...")
        bg_c = parse_color(p.subject_bg_color) or (0, 0, 0)
        export_subject_video(video_path, matte_dir, str(out / "subject_isolated.mp4"), fps, bg_color=bg_c)

    if p.export_matte_video:
        _update_job(job_id, progress="Exporting matte video...")
        export_matte_video(matte_dir, str(out / "matte.mp4"), fps)

    _unload_gvm()


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    _load_jobs_on_startup()
    worker = threading.Thread(target=_worker_loop, daemon=True, name="gpu-worker")
    worker.start()
    logger.info("CorridorKey API started — GPU worker running")
    yield
    _job_queue.put(None)  # shutdown signal
    worker.join(timeout=5)
    logger.info("CorridorKey API shutdown")


app = FastAPI(
    title="CorridorKey API",
    description="Neural green screen keying, background replacement & subject isolation",
    version="1.0.0",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Utility endpoints
# ---------------------------------------------------------------------------

@app.get("/api/v1/health")
def health():
    return {"status": "ok"}


@app.get("/api/v1/device")
def device_info():
    device = resolve_device("auto")
    info: dict[str, Any] = {"device": device}
    try:
        import torch
        if torch.cuda.is_available():
            info["gpu_name"] = torch.cuda.get_device_name(0)
            info["vram_total_gb"] = round(torch.cuda.get_device_properties(0).total_mem / 1e9, 1)
            info["vram_allocated_gb"] = round(torch.cuda.memory_allocated(0) / 1e9, 2)
    except Exception:
        pass
    return info


# ---------------------------------------------------------------------------
# Job submission endpoints
# ---------------------------------------------------------------------------

@app.post("/api/v1/jobs/background-replace", response_model=JobResponse)
async def submit_bg_replace(
    video: UploadFile = File(..., description="Input video"),
    background_image: UploadFile | None = File(None, description="Background image (optional)"),
    background_video: UploadFile | None = File(None, description="Background video (optional, loops)"),
    selection_mask: UploadFile | None = File(None, description="Binary selection mask PNG (optional)"),
    params: str = Form("{}"),
):
    """Submit a background replacement job. Returns immediately with a job ID."""
    p = BackgroundReplaceParams.model_validate_json(params)
    job_id = str(uuid.uuid4())
    inp = _job_dir(job_id) / "input"
    inp.mkdir(parents=True)

    await _save_upload(video, inp / "video.mp4")
    if background_image and background_image.filename:
        await _save_upload(background_image, inp / "background_image.png")
    if background_video and background_video.filename:
        await _save_upload(background_video, inp / "background_video.mp4")
    if selection_mask and selection_mask.filename:
        await _save_upload(selection_mask, inp / "selection_mask.png")

    meta = _create_job(job_id, JobType.background_replace, p.model_dump())
    _job_queue.put(job_id)
    return _meta_to_response(meta)


@app.post("/api/v1/jobs/greenscreen-key", response_model=JobResponse)
async def submit_greenscreen_key(
    video: UploadFile = File(..., description="Green screen video"),
    alpha_hint: UploadFile | None = File(None, description="Alpha hint video (optional, auto-generated with GVM if omitted)"),
    params: str = Form("{}"),
):
    """Submit a green screen keying job."""
    p = GreenScreenKeyParams.model_validate_json(params)
    job_id = str(uuid.uuid4())
    inp = _job_dir(job_id) / "input"
    inp.mkdir(parents=True)

    await _save_upload(video, inp / "video.mp4")
    if alpha_hint and alpha_hint.filename:
        await _save_upload(alpha_hint, inp / "alpha_hint.mp4")

    meta = _create_job(job_id, JobType.greenscreen_key, p.model_dump())
    _job_queue.put(job_id)
    return _meta_to_response(meta)


@app.post("/api/v1/jobs/rotoscope", response_model=JobResponse)
async def submit_rotoscope(
    video: UploadFile = File(..., description="Input video"),
    selection_mask: UploadFile | None = File(None, description="Binary selection mask PNG (optional)"),
    params: str = Form("{}"),
):
    """Submit a rotoscope / subject isolation job."""
    p = RotoscopeParams.model_validate_json(params)
    job_id = str(uuid.uuid4())
    inp = _job_dir(job_id) / "input"
    inp.mkdir(parents=True)

    await _save_upload(video, inp / "video.mp4")
    if selection_mask and selection_mask.filename:
        await _save_upload(selection_mask, inp / "selection_mask.png")

    meta = _create_job(job_id, JobType.rotoscope, p.model_dump())
    _job_queue.put(job_id)
    return _meta_to_response(meta)


# ---------------------------------------------------------------------------
# Job status / listing / cancellation
# ---------------------------------------------------------------------------

@app.get("/api/v1/jobs/{job_id}", response_model=JobResponse)
def get_job_status(job_id: str):
    """Poll job status. Includes result file manifest when completed."""
    meta = _get_job(job_id)
    if meta is None:
        raise HTTPException(404, f"Job {job_id} not found")
    resp = _meta_to_response(meta)
    if resp.status == JobStatus.completed:
        resp.result_files = _scan_result_files(job_id)
    return resp


@app.get("/api/v1/jobs", response_model=list[JobResponse])
def list_jobs(
    limit: int = Query(20, ge=1, le=100),
    status: JobStatus | None = Query(None),
):
    """List recent jobs, newest first."""
    with _jobs_lock:
        all_jobs = list(_jobs.values())
    if status:
        all_jobs = [j for j in all_jobs if j["status"] == status.value]
    all_jobs.sort(key=lambda j: j.get("created_at", ""), reverse=True)
    return [_meta_to_response(j) for j in all_jobs[:limit]]


@app.delete("/api/v1/jobs/{job_id}")
def delete_job(job_id: str):
    """Cancel a queued job or delete a completed/failed job and its files."""
    meta = _get_job(job_id)
    if meta is None:
        raise HTTPException(404, f"Job {job_id} not found")

    if meta["status"] == JobStatus.queued.value:
        _update_job(job_id, status=JobStatus.cancelled.value)
    elif meta["status"] == JobStatus.running.value:
        raise HTTPException(409, "Cannot delete a running job. Wait for it to finish.")

    # Clean up files
    jdir = _job_dir(job_id)
    if jdir.exists():
        shutil.rmtree(jdir, ignore_errors=True)
    with _jobs_lock:
        _jobs.pop(job_id, None)

    return {"status": "deleted", "job_id": job_id}


# ---------------------------------------------------------------------------
# File download endpoints
# ---------------------------------------------------------------------------

@app.get("/api/v1/jobs/{job_id}/files/{file_path:path}")
def download_file(
    job_id: str,
    file_path: str,
    archive: str | None = Query(None, description="Set to 'zip' to download a directory as ZIP"),
):
    """Download a result file or directory (as ZIP)."""
    meta = _get_job(job_id)
    if meta is None:
        raise HTTPException(404, f"Job {job_id} not found")
    if meta["status"] != JobStatus.completed.value:
        raise HTTPException(409, "Job is not completed yet")

    target = _job_dir(job_id) / "output" / file_path

    if target.is_dir():
        if archive == "zip":
            buf = _make_zip(target)
            return StreamingResponse(
                buf,
                media_type="application/zip",
                headers={"Content-Disposition": f'attachment; filename="{target.name}.zip"'},
            )
        # List directory contents
        files = []
        for p in sorted(target.rglob("*")):
            if p.is_file():
                rel = p.relative_to(_job_dir(job_id) / "output")
                files.append({"name": p.name, "path": str(rel), "size_bytes": p.stat().st_size})
        return {"directory": file_path, "files": files}

    if not target.is_file():
        raise HTTPException(404, f"File not found: {file_path}")

    return FileResponse(
        str(target),
        media_type=_guess_content_type(target.suffix),
        filename=target.name,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _meta_to_response(meta: dict) -> JobResponse:
    return JobResponse(
        job_id=meta["job_id"],
        job_type=meta["job_type"],
        status=meta["status"],
        created_at=meta["created_at"],
        started_at=meta.get("started_at"),
        completed_at=meta.get("completed_at"),
        progress=meta.get("progress"),
        error=meta.get("error"),
    )


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    import uvicorn

    parser = argparse.ArgumentParser(description="CorridorKey API Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    uvicorn.run(app, host=args.host, port=args.port)
